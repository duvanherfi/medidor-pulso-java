--
-- Base de datos: `medidorpulso`
--
CREATE DATABASE IF NOT EXISTS `medidorpulso` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `medidorpulso`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `id` int(11) NOT NULL,
  `nombres` varchar(20) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `peso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`id`, `nombres`, `apellidos`, `edad`, `peso`) VALUES
(1, 'Duvan', 'Hernandez', 21, 82);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rango_pulso`
--

CREATE TABLE `rango_pulso` (
  `rango` varchar(15) NOT NULL,
  `descripcion` text,
  `recomendacion` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `rango_pulso`
--

INSERT INTO `rango_pulso` (`rango`, `descripcion`, `recomendacion`) VALUES
('1', '60-80.\r\n\r\npulso es normal.', 'Tú pulso es normal, sigue con tu estilo de vida.'),
('2', 'pulso<60.\r\n\r\nLa Bradicardia:\r\nUna frecuencia cardíaca lenta puede ser normal y saludable. O puede ser una señal de un problema con el sistema eléctrico del corazón.', 'Con frecuencia la bradicardia es el resultado de otra afección cardíaca, así que tomar medidas para llevar un estilo de vida saludable para el corazón suele mejorar el estado de salud general. Estas medidas incluyen:\r\n\r\nSeguir un plan de alimentación saludable para el corazón que incluya muchas frutas, verduras, granos integrales, pescado y productos lácteos descremados o semidescremados.\r\nHacer actividad la mayoría de los días de la semana o bien todos los días. Su médico puede indicarle qué nivel de ejercicio es seguro para usted.\r\nBajar de peso si lo necesita y mantener un peso saludable.\r\nNo fumar.\r\nManejar otros problemas de salud, como la presión arterial alta o el colesterol alto.'),
('3', 'pulso>80.\r\n\r\nSe trata de un factor que hay que cuidar para controlar la salud del corazón y detectar a tiempo múltiples problemas. Se considera que el ritmo del corazón es rápido cuando su frecuencia es mayor a 100 latidos por minuto estando en reposo.', 'Un pulso acelerado es muy delicado para dar recomendaciones, así que visita al medico lo antes posible.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_pulso`
--

CREATE TABLE `registro_pulso` (
  `id` int(11) NOT NULL,
  `rango` varchar(15) DEFAULT NULL,
  `id_persona` int(11) DEFAULT NULL,
  `pulso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `registro_pulso`
--

INSERT INTO `registro_pulso` (`id`, `rango`, `id_persona`, `pulso`) VALUES
(1, '1', 1, 80);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_persona` int(11) NOT NULL,
  `user` varchar(20) NOT NULL,
  `contraseña` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_persona`, `user`, `contraseña`) VALUES
(1, 'duvanherfi', '8f0c0e404ba87b0c38cca157eec9ff74');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rango_pulso`
--
ALTER TABLE `rango_pulso`
  ADD PRIMARY KEY (`rango`);

--
-- Indices de la tabla `registro_pulso`
--
ALTER TABLE `registro_pulso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rango` (`rango`),
  ADD KEY `id_persona` (`id_persona`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_persona`,`user`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `registro_pulso`
--
ALTER TABLE `registro_pulso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `registro_pulso`
--
ALTER TABLE `registro_pulso`
  ADD CONSTRAINT `registro_pulso_ibfk_1` FOREIGN KEY (`rango`) REFERENCES `rango_pulso` (`rango`),
  ADD CONSTRAINT `registro_pulso_ibfk_2` FOREIGN KEY (`id_persona`) REFERENCES `usuarios` (`id_persona`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
